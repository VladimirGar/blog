export const myToken = {
    url: 'https://api.react-learning.ru',
    token: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJfaWQiOiI2MjY2Y2NjNDQzOGE3N2NhOGYyODc3ZTUiLCJpYXQiOjE2NTA5MDQyODUsImV4cCI6MTY4MjQ0MDI4NX0.rZ4wMpageIl_aN42FVM8QMvZoQtusRPs3TArbZQqdbA'
}