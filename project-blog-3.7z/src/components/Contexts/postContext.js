import { createContext } from "react";
const PostContext = createContext(null);
export default PostContext